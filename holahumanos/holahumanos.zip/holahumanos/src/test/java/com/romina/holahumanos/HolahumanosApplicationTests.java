package com.romina.holahumanos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HolahumanosApplicationTests {

	@Test
	void contextLoads() {
	}

}
