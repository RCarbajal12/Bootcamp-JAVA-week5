package com.romina.cadenas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadenasApplicationTests {

	@Test
	void contextLoads() {
	}

}
