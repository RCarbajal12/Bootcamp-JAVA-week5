
alert("Esta es la plantilla de fecha actual");