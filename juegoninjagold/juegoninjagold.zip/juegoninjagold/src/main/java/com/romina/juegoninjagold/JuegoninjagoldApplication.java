package com.romina.juegoninjagold;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JuegoninjagoldApplication {

	public static void main(String[] args) {
		SpringApplication.run(JuegoninjagoldApplication.class, args);
	}

}
